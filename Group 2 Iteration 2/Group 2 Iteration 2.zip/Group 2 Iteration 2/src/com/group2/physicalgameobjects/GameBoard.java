package com.group2.physicalgameobjects;

public class GameBoard {
//INSTANCE VARIABLES
    Square[][];//Todo make size
    //CONSTRUCTOR
    public GameBoard() {
        //Todo compile blank squares.

    }

//METHODS

}