package com.group2.physicalgameobjects;

public class HumanPlayer extends Player {

    public HumanPlayer(){
        super();
    }
}
