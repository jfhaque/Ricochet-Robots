package com.group2.physicalgameobjects;

public class SimpleBoard extends GameBoard {

    public SimpleBoard() {
        super();
    }
}
