package com.group2.physicalgameobjects;

public class Square {
}
