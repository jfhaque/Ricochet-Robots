package com.group2.physicalgameobjects;

public class ComplexBoard extends GameBoard {


    public ComplexBoard(){
        super();
    }
}
