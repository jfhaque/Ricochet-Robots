package com.group2.physicalgameobjects;

public class ComputerPlayer extends Player {


    public ComputerPlayer(){
        super();
    }
}
