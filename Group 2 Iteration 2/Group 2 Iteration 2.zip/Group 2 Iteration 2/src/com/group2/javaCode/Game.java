
public class Game {

    public static void main(String[] args) {

        StartMenuGUI newStartMenu = new StartMenuGUI();
    }
}