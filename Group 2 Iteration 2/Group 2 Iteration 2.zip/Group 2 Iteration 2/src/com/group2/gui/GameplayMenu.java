package com.group2.gui;

import javax.swing.*;

public class GameplayMenu extends JFrame{


    public GameplayMenu(){




        pack();
        setVisible(true);
    }


}
