package com.group2.gui;

import java.awt.*;

public class Robot {

    private static final Color[] robotColours = {
            new Color(245, 99, 99), //Color.RED,
            new Color(99, 245, 99), //Color.GREEN,
            new Color(99, 99, 245), //Color.BLUE,
            new Color(245, 245, 99),//Color.YELLOW,
    };
    public static final String[] robotShapes = {
            "circle", "triangle", "square", "hexagon"
    };
}